package app.iosbanners

import android.app.KeyguardManager
import android.app.Notification
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

/**
 * Recebe as notificações reais do sistema (API oficial NotificationListenerService)
 * e as repassa ao banner. Não armazena nem transmite o conteúdo.
 */
class NotificationService : NotificationListenerService() {

    companion object {
        @Volatile
        var connected: Boolean = false

        /** Marca a notificação de teste enviada pelo próprio app (botão "Enviar teste"). */
        const val EXTRA_IS_TEST = "app.iosbanners.IS_TEST"
        private const val TAG = "IosBanners"
    }

    private lateinit var overlay: BannerOverlay
    private val lastHash = HashMap<String, Int>()

    override fun onCreate() {
        super.onCreate()
        overlay = BannerOverlay(this)
    }

    override fun onDestroy() {
        overlay.release()
        super.onDestroy()
    }

    override fun onListenerConnected() {
        connected = true
    }

    override fun onListenerDisconnected() {
        connected = false
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) lastHash.remove(sbn.key)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            handle(sbn)
        } catch (t: Throwable) {
            Log.e(TAG, "Falha ao processar notificação", t)
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (!Prefs.enabled(this)) return
        val n = sbn.notification ?: return
        val pkg = sbn.packageName
        val ownPackage = pkg == packageName

        // Do próprio app, só passa a notificação de teste.
        val extras = n.extras
        if (ownPackage && extras?.getBoolean(EXTRA_IS_TEST, false) != true) return
        if (!ownPackage && pkg !in Prefs.monitoredApps(this)) return

        // Ignora resumos de grupo, serviços em primeiro plano, mídia e progresso.
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_FOREGROUND_SERVICE)) != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT,
            Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE,
            Notification.CATEGORY_SYSTEM,
            Notification.CATEGORY_STATUS -> return
        }
        if (extras == null) return

        val pm = packageManager
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        val appIcon: Drawable? = try {
            pm.getApplicationIcon(pkg)
        } catch (e: Exception) {
            null
        }

        var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        var body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (body.isBlank()) {
            body = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                ?.lastOrNull()?.toString().orEmpty()
        }
        var avatar: Drawable? = null
        var messageCount = 0

        // Conversas (MessagingStyle): pega a última mensagem, o remetente e a foto.
        @Suppress("DEPRECATION")
        val rawMessages = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
        if (rawMessages != null && rawMessages.isNotEmpty()) {
            val list = Notification.MessagingStyle.Message.getMessagesFromBundleArray(rawMessages)
            if (list.isNotEmpty()) {
                val last = list.last()
                val lastText = last.text?.toString().orEmpty()
                val person = last.senderPerson
                val senderName = person?.name?.toString().orEmpty()
                val conversation = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
                messageCount = list.size
                if (lastText.isNotEmpty()) {
                    if (!conversation.isNullOrEmpty()) {
                        title = conversation
                        body = if (senderName.isNotEmpty()) "$senderName: $lastText" else lastText
                    } else {
                        if (senderName.isNotEmpty()) title = senderName
                        body = lastText
                    }
                }
                avatar = try {
                    person?.icon?.loadDrawable(this)
                } catch (e: Exception) {
                    null
                }
            }
        }
        if (avatar == null) {
            avatar = try {
                n.getLargeIcon()?.loadDrawable(this)
            } catch (e: Exception) {
                null
            }
        }

        if (title.isBlank()) title = appName
        if (title.isBlank() && body.isBlank()) return

        // Evita repetir a mesma atualização da mesma notificação.
        val hash = (title + "\u0000" + body + "\u0000" + messageCount + "\u0000" + n.`when`).hashCode()
        if (lastHash[sbn.key] == hash) return
        if (lastHash.size > 300) lastHash.clear()
        lastHash[sbn.key] = hash

        val data = CardData(
            key = sbn.key,
            packageName = pkg,
            appName = appName,
            title = title,
            body = body,
            appIcon = appIcon,
            avatar = avatar,
            contentIntent = n.contentIntent,
            postTime = sbn.postTime
        )
        route(data)
    }

    private fun route(data: CardData) {
        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        val screenOn = pm?.isInteractive != false
        val locked = km?.isKeyguardLocked == true
        if (screenOn && !locked) {
            val shown = overlay.show(data)
            // Só remove a original se o nosso cartão realmente apareceu.
            if (shown && Prefs.hideOriginal(this)) {
                try {
                    cancelNotification(data.key)
                } catch (e: Exception) {
                    Log.w(TAG, "Não foi possível remover a original", e)
                }
            }
        } else if (!screenOn && Prefs.lockCard(this) && Settings.canDrawOverlays(this)) {
            // Experimental: com a tela apagada, acende fraco só o cartão sobre fundo preto
            // (não é o AOD). Não remove a original.
            try {
                CardStore.pending = data
                val i = Intent(this, LockCardActivity::class.java)
                i.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
                startActivity(i)
            } catch (e: Exception) {
                Log.w(TAG, "Não foi possível abrir o cartão na tela bloqueada", e)
            }
        }
    }
}
