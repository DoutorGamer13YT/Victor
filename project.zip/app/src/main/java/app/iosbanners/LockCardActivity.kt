package app.iosbanners

import android.app.Activity
import android.app.KeyguardManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import kotlin.random.Random

/**
 * EXPERIMENTAL. Usado quando a notificação chega com a tela apagada: acende a tela bem fraca,
 * sem barras do sistema, com fundo preto puro e só o cartão. Em tela AMOLED o preto fica apagado,
 * então visualmente sobra só a notificação.
 *
 * Isso NÃO é o Always On Display: a tela fica realmente ligada (Activity com setShowWhenLocked +
 * setTurnScreenOn) até o tempo limite de tela do sistema, ou até o limite de segurança abaixo.
 * A posição vertical varia a cada notificação para reduzir burn-in.
 */
class LockCardActivity : Activity() {

    private companion object {
        const val BRIGHTNESS = 0.2f
        const val MAX_VISIBLE_MS = 20000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val finishRunnable = Runnable { finish() }
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        val attrs = window.attributes
        attrs.screenBrightness = BRIGHTNESS
        window.attributes = attrs

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        // Toque fora do cartão: fecha e volta ao bloqueio.
        root.setOnClickListener { finish() }
        setContentView(root)
        hideSystemBars()
        render(CardStore.pending)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        render(CardStore.pending)
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            val c = window.insetsController
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
    }

    private fun render(data: CardData?) {
        if (data == null) {
            finish()
            return
        }
        root.removeAllViews()
        val card = NotificationCardView(this)
        card.bind(data, Prefs.darkCard(this), false)
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        // Posição vertical variável (anti burn-in).
        lp.setMargins(dp(8), dp(72) + Random.nextInt(dp(160)), dp(8), 0)
        root.addView(card, lp)

        card.alpha = 0f
        card.translationY = -dp(30).toFloat()
        card.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(380)
            .setInterpolator(PathInterpolator(0.2f, 0.9f, 0.2f, 1f))
            .start()

        card.setOnClickListener { openAfterUnlock(data) }

        handler.removeCallbacks(finishRunnable)
        handler.postDelayed(finishRunnable, MAX_VISIBLE_MS)
    }

    private fun openAfterUnlock(data: CardData) {
        handler.removeCallbacks(finishRunnable)
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() {
                openSource(applicationContext, data)
                finish()
            }

            override fun onDismissCancelled() {
                finish()
            }

            override fun onDismissError() {
                finish()
            }
        })
    }

    override fun onStop() {
        super.onStop()
        // Quando a tela apaga pelo tempo limite do sistema (ou outro app abre), encerra o cartão.
        if (!isFinishing) finish()
    }

    override fun onDestroy() {
        handler.removeCallbacks(finishRunnable)
        super.onDestroy()
    }
}
