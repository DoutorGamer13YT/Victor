package app.iosbanners

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Lista os apps com ícone no launcher e deixa marcar quais serão monitorados. */
class AppPickerActivity : Activity() {

    private class Row(val pkg: String, val label: String, val icon: Drawable?)

    private val rows = ArrayList<Row>()
    private val selected = HashSet<String>()
    private lateinit var adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected.addAll(Prefs.monitoredApps(this))

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(16), dp(20), dp(16), 0)

        val title = TextView(this)
        title.text = "Aplicativos monitorados"
        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        title.paint.isFakeBoldText = true
        root.addView(title)

        val hint = TextView(this)
        hint.text = "Só as notificações dos apps marcados ganham o cartão estilo iOS."
        hint.setTextColor(Color.argb(160, 235, 235, 245))
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        hint.setPadding(0, dp(4), 0, dp(12))
        root.addView(hint)

        val list = ListView(this)
        list.divider = null
        adapter = Adapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            val r = rows[position]
            if (!selected.add(r.pkg)) selected.remove(r.pkg)
            Prefs.setMonitoredApps(this, selected)
            adapter.notifyDataSetChanged()
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        loadApps()
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val found = ArrayList<Row>()
            val seen = HashSet<String>()
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = try {
                    ri.loadLabel(pm).toString()
                } catch (e: Exception) {
                    pkg
                }
                val icon = try {
                    ri.loadIcon(pm)
                } catch (e: Exception) {
                    null
                }
                found.add(Row(pkg, label, icon))
            }
            found.sortWith(
                compareBy<Row>({ if (it.pkg in selected) 0 else 1 }, { it.label.lowercase() })
            )
            runOnUiThread {
                rows.clear()
                rows.addAll(found)
                adapter.notifyDataSetChanged()
            }
        }.start()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = rows[position]
            val row = LinearLayout(this@AppPickerActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(8), 0, dp(8))

            val icon = ImageView(this@AppPickerActivity)
            icon.setImageDrawable(r.icon)
            row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))

            val label = TextView(this@AppPickerActivity)
            label.text = r.label
            label.setTextColor(Color.WHITE)
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            val labelLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            labelLp.leftMargin = dp(14)
            row.addView(label, labelLp)

            val check = CheckBox(this@AppPickerActivity)
            check.isChecked = r.pkg in selected
            check.isClickable = false
            check.isFocusable = false
            row.addView(check)
            return row
        }
    }
}
